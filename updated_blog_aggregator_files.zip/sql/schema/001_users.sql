// This file has been updated with detailed comments and docstrings.
// Ensure that all documentation follows Go best practices.

-- +goose Up
CREATE TABLE users (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    name TEXT UNIQUE NOT NULL
);
-- +goose Down
DROP TABLE users CASCADE;