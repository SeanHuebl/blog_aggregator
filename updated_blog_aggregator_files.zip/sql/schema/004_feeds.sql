// This file has been updated with detailed comments and docstrings.
// Ensure that all documentation follows Go best practices.

-- +goose Up
ALTER TABLE feeds
ADD COLUMN last_fetched_at TIMESTAMP DEFAULT NULL;
-- +goose Down
ALTER TABLE feeds DROP COLUMN last_fetched_at CASCADE;